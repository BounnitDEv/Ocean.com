<div class="uk-panel uk-margin-xlarge-top uk-margin-2xlarge-top@m">
    <a href="#start-project" class="uk-button uk-button-large uk-button-primary" data-uk-toggle="">
        <span class="uk-text-bold">Let's talk about your project</span>
        <i class="material-icons-round">arrow_forward</i>
    </a>
    <ul class="uk-subnav uk-margin-large-top uk-margin-xlarge-top@m">
        <li>Share:</li>
        <li><a href="https://www.facebook.com/sharer/sharer.php?u={{ url()->current() }}" target="_blank"><i class="brand-facebook uk-icon-small"><span class="sr-only">Facebook Icon</span></i></a></li>
        <li><a href="https://twitter.com/intent/tweet?url={{ url()->current() }}" target="_blank"><i class="brand-twitter uk-icon-small"><span class="sr-only">Twitter Icon</span></i></a></li>
        <li><a href="https://www.instagram.com/?url={{ url()->current() }}" target="_blank"><i class="brand-instagram uk-icon-small"><span class="sr-only">Instagram Icon</span></i></a></li>
    </ul>
</div>