<div class="section-empty no-paddings">
            <div class="content">

                <div class="grid-list gallery">
                    <div class="grid-box no-margins row" data-lightbox-anima="fade-top">
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/1.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/1.webp')}}" alt="">
                            </a>
                        </div>
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/2.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/2.webp')}}" alt="">
                            </a>
                        </div>
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/3.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/3.webp')}}" alt="">
                            </a>
                        </div>
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/4.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/4.webp')}}" alt="">
                            </a>
                        </div>
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/5.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/5.webp')}}" alt="">
                            </a>
                        </div>
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/6.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/6.webp')}}" alt="">
                            </a>
                        </div>
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/7.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/7.webp')}}" alt="">
                            </a>
                        </div>
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/8.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/8.webp')}}" alt="">
                            </a>
                        </div>
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/9.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/9.webp')}}" alt="">
                            </a>
                        </div>
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/10.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/10.webp')}}" alt="">
                            </a>
                        </div>
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/11.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/11.webp')}}" alt="">
                            </a>
                        </div>
                        <div class="grid-item col-md-2">
                            <a class="img-box i-center" href="{{ asset('assets/images/img/gallery/12.webp') }}" data-anima="show-scale" data-trigger="hover" data-anima-out="hide">
                                <i class="im-old-camera anima"></i>
                                <img src="{{ asset('assets/images/img/gallery/12.webp')}}" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>